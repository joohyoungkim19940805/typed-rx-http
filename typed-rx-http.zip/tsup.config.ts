import { defineConfig } from "tsup";

export default defineConfig({
  entry: {
    index: "src/index.ts",
    next: "src/next.ts",
    rsocket: "src/rsocket.ts",
  },
  format: ["esm", "cjs"],
  dts: true,
  sourcemap: true,
  clean: true,
  treeshake: true,

  //  Next 없는 환경에서도 빌드되게
  external: [
    "next",
    "next/*",
    "buffer",
    "rsocket-core",
    "rsocket-types",
    "rsocket-websocket-client",
  ],
});
